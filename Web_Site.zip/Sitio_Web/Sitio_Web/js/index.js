localStorage.setItem("USR", "AndreG");
localStorage.setItem("PWD", "AndGui1034");

var email = localStorage.getItem("USR");
var password = localStorage.getItem("PWD");

function validar(){
    var input_usr = document.getElementById("email").value;
    var input_pwd = document.getElementById("password").value;

    if (input_usr == email && input_pwd == password)
        window.open("paginas/pagina_principal.html", "_blank");
    else
        alert("Incorrecto");
}