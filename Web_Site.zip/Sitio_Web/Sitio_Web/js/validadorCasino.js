function validar_casino(){
    var num;

    num = prompt("Ingresa tu edad");
    parseInt(num);

    if(num < 0)
        alert("Esa edad no existe");
    else if(num >= 0 && num < 18)
        alert("No puedes entrar");
    else if(num >= 18 && num < 40)
        alert("Adelante pasa");
    else if(num >= 40 && num < 99)
        alert("Ya esta ruco");
    else
        alert("Debería estar escogiendo la madera, no aqui");
}