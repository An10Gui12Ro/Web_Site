var num = 0, ans = 0, prev_op = "+", error = false, flt = false;

window.onload = function() {
    celda = document.getElementById("num");
};

function operation(){
    if(flt){
        num = parseFloat(num);
        ans = parseFloat(ans);
    }
    flt = false;
    if(prev_op == "+")
        ans += num;
    else if(prev_op == "-")
        ans -= num;
    else if(prev_op == "*")
        ans *= num;
    else if(prev_op == "/"){
        if(num == 0){
            celda.textContent = "math error";
            num = 0;
            ans = 0;
            prev_op = "+";
            error = true;
        }
        else
            ans /= num;
    }
    num = 0;
}

function sum(){
    operation();
    if(!error){
        celda.textContent = ans;
        prev_op = "+";
    }
}

function diff(){
    operation();
    if(!error){
        celda.textContent = ans;
        prev_op = "-";
    }
}

function division(){
    operation();
    if(!error){
        celda.textContent = ans;
        prev_op = "/";
    }
}

function product(){
    operation();
    if(!error){
        celda.textContent = ans;
        prev_op = "*";
    }
}

function result(){
    operation();
    if(!error){
        prev_op = "+";
        num = 0;
        celda.textContent = ans;
    }
}

function reset(){
    celda.textContent = "";
    num = 0;
    ans = 0;
    prev_op = "+";
    error = false
    flt = false;
    celda.textContent = 0;
}

function write_number(){
    celda.textContent = num;
}

function float(){
    flt = true;
    num += '.'
}

//BOTONES NUMEROS

function zero(){
    if(!error){
        if(flt)
            num += '0';
        else{
            num *= 10;
            num += 0;
        }
        write_number();
    }
}

function one(){
    if(!error){
        if(flt)
            num += '1';
        else{
            num *= 10;
            num += 1;
        }
        write_number();
    }
}

function two(){
    if(!error){
        if(flt)
            num += '2';
        else{
            num *= 10;
            num += 2;
        }
        write_number();   
    }
}

function three(){
    if(!error){
        if(flt)
            num += '3';
        else{
            num *= 10;
            num += 3;
        }
        write_number();   
    }
}

function four(){
    if(!error){
        if(flt)
            num += '4';
        else{
            num *= 10;
            num += 4;
        }
        write_number();   
    }
}

function five(){
    if(!error){
        if(flt)
            num += '5';
        else{
            num *= 10;
            num += 5;
        }
        write_number();   
    }
}

function six(){
    if(!error){
        if(flt)
            num += '6'
        else{
            num *= 10;
            num += 6;
        }
        write_number();   
    }
}

function seven(){
    if(!error){
        if(flt)
            num += '7'
        else{
            num *= 10;
            num += 7;
        }
        write_number();   
    }
}

function eight(){
    if(!error){
        if(flt)
            num += '8'
        else{
            num *= 10;
            num += 8;
        }
        write_number();   
    }
}

function nine(){
    if(!error){
        if(flt)
            num += '9'
        else{
            num *= 10;
            num += 9;
        }
        write_number();   
    }
}