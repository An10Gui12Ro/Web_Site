function validar(){
    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var status = document.getElementById("active").value;
    var grade = document.getElementById("grade").value;
    var password = document.getElementById("password").value;

    let errores = [];

    let names = name.trim().split(/\s+/);
    if(names.length > 4)
        errores.push("Demasiadas palabras");
    else{
        for(let elemento of names){
            let pos = elemento.search(/\d+/);
            if(pos != -1){
                errores.push("Tu nombre no debe de incluir numeros");
                break;
            }
        }
    }

    let email_parts = email.split('@');
    if(email_parts.length == 2){
        let domain_parts = email_parts[1].split(".");
        if (domain_parts.length < 2 || domain_parts.some(part => part === ""))
            errores.push("Error con el dominio del correo")
    }
    else
        errores.push("Error con el @ del correo");


    if(parseInt(status) != 0 && parseInt(status) != 1)
        errores.push("El status debe ser un 0 o 1");

    if(grade == "" || parseFloat(grade) < 0 || parseFloat(grade) > 10)
        errores.push("El grade deber ser un numero entre 0 y 10");

    if(password.length < 6)
        errores.push("Contraseña demasiado pequeña");
    else{
        let pos = password.search(/[A-Z]/);
        if(pos == -1)
            errores.push("Tu contraseña no tiene letras mayusculas");

        pos = password.search(/[a-z]/);
        if(pos == -1)
            errores.push("Tu contraseña no tiene letras minusculas");;
    }

    let cadena = errores.join(". ");
    alert(cadena);
}