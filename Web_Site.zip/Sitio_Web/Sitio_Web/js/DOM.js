var parrafo = document.createElement("h1");

var contenido = document.createTextNode("Hola Mundo!");

parrafo.appendChild(contenido);

document.body.appendChild(parrafo);

