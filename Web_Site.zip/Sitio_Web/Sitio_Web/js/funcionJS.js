var num = 0, num2 = 0, res = 0;

function sum_and_show(){
    num = prompt("Ingresa el primer numero");
    num2 = prompt("Ingresa el segundo numero");
    res = parseInt(num) + parseInt(num2);
    alert("El resultado de la suma es: " + res);
}