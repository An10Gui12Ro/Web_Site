alert("Esta esa una alerta");
console.log("Soy un mensaje para depurar");