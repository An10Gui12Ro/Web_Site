function getWeather() {
    const city = document.getElementById('city').value;  // Obtener ciudad del input
    if (!city) {
        alert("Por favor, ingresa el nombre de una ciudad.");
        return;
    }
    
    const apiKey = 'e50dea4e3b3c2d383c94979dbd1aed46'; // Reemplaza con tu clave de OpenWeatherMap
    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric&lang=es`;

    // Realizar la consulta a la API
    fetch(apiUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al obtener los datos del clima');
            }
            return response.json();
        })
        .then(data => {
            // Mostrar la información del clima
            const weatherContainer = document.querySelector('#weather');
            weatherContainer.innerHTML = `
                <h2>Clima en ${data.name}</h2>
                <p>Temperatura: ${data.main.temp}°C</p>
                <p>Descripción: ${data.weather[0].description}</p>
                <p>Humedad: ${data.main.humidity}%</p>
            `;
        })
        .catch(error => {
            console.error('Hubo un error:', error);
            const weatherContainer = document.querySelector('#weather');
            weatherContainer.innerHTML = `<p>No se pudo obtener el clima para la ciudad '${city}'.</p>`;
        });
}