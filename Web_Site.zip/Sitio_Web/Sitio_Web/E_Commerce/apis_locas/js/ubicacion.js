function get_ubicacion() {
    const apiKey = '8aa62fba6d6c46a883d4a2758351c891';
    const apiUrl = `https://api.ipgeolocation.io/ipgeo?apiKey=${apiKey}`;
  
    fetch(apiUrl)
      .then(response => response.json())
      .then(data => {
        const resultDiv = document.getElementById('result');
        const { ip, city, country_name, latitude, longitude } = data;
  
        resultDiv.innerHTML = `
          <p><strong>IP:</strong> ${ip}</p>
          <p><strong>Ciudad:</strong> ${city}</p>
          <p><strong>País:</strong> ${country_name}</p>
          <p><strong>Latitud:</strong> ${latitude}</p>
          <p><strong>Longitud:</strong> ${longitude}</p>
        `;
      })
      .catch(error => {
        console.error('Error:', error);
        document.getElementById('result').innerHTML = 'No se pudo obtener la ubicación.';
      });
  }
  
  // Asignar el evento de clic al botón
  document.getElementById('getLocationBtn').addEventListener('click', get_ubicacion);
  