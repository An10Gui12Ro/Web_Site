const products_container = document.getElementById('products_container');

//UPDATE CART
function update_cart(products){
    if(products){
        /*console.log(products);*/

        products.forEach(product => {
            const new_product = document.createElement("div");
            new_product.id = `${product.name}_${product.id}`;

            new_product.innerHTML = `
                <img src= ${product.img}>
                <h3>${product.name}</h3>
                <p>$${product.price}</p>
                <div>
                    <button>-</button>
                    <span class="amount">${product.amount}</span>
                    <button>+</button>
                </div>
            `;

            products_container.appendChild(new_product);

            new_product.getElementsByTagName("button")[0].addEventListener("click", (e) => {
                products_container.innerHTML = "";
                delete_from_cart(product);
            });

            new_product.getElementsByTagName("button")[1].addEventListener("click", (e) => {
                products_container.innerHTML = "";
                add_to_cart(product);
            });
        })
    }
}

update().then(products =>{
    update_cart(products);
})
//UPDATE CART

//DELETE CART
const del_cart = document.getElementById("delete_cart");
del_cart.addEventListener("click", delete_cart);

async function delete_cart() {
    /*console.log("elimnar");*/
    try {
        const response = await fetch('http://localhost:4000/cart/delete/all', {
            method: 'DELETE'
        });

        if (!response.ok) throw new Error('Error deleting all items in cart');
        
        // Actualiza elementos en el carrito
        //No entra porque no se devuelve una promesa ya que el carrito está vacío
        /*update().then(products =>{
            update_cart(products);
        })*/
        products_container.innerHTML = "";
        n_items().then(n_items =>{
            update_number_of_items(n_items);
        })
        cart_empty().then(total =>{
            is_cart_empty(total);
        })
    } catch (error) {
        console.error('Error deleting all items in cart:', error);
    }
}
//DELETE CART