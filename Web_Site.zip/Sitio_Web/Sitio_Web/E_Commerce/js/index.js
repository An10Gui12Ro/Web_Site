const images = document.getElementById('carouselImages');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');
const totalImages = images.children.length;
let index = 0;

function showImage(offset) {
    index = (index + offset + totalImages) % totalImages;
    images.style.transform = `translateX(-${index * 100}%)`;
}

prevBtn.addEventListener('click', () => showImage(-1));
nextBtn.addEventListener('click', () => showImage(1));