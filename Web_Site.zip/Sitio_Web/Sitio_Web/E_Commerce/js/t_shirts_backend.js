async function get_t_shirts(){
    const res = await fetch('http://localhost:4000/t_shirts');
    const resJson = await res.json();
    return resJson;
}