const t_shirts_container = document.getElementById('t_shirts_container');


function create_cards_t_shirts(t_shirts){
    t_shirts.forEach(t_shirt =>{
        const new_t_shirt = document.createElement("div");
        new_t_shirt.id = `t_shirt_${t_shirt.id}`;

        new_t_shirt.innerHTML = `
            <img src= ${t_shirt.img}>
            <h3>${t_shirt.name}</h3>
            <p>$${t_shirt.price}</p>
            <button>Agregar al carrito</button>
        `;
        
        t_shirts_container.appendChild(new_t_shirt);

        new_t_shirt.getElementsByTagName("button")[0].addEventListener("click", () => add_to_cart(t_shirt));
    })
}

get_t_shirts().then(t_shirts =>{
    create_cards_t_shirts(t_shirts);
})


n_items().then(n_items =>{
    update_number_of_items(n_items);
})