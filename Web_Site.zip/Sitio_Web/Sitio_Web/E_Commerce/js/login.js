localStorage.setItem("user", "tonymontana");
localStorage.setItem("password", "1234");

var email = localStorage.getItem("user");
var password = localStorage.getItem("password");

function validar(){
    var input_usr = document.getElementById("usuario").value;
    var input_pwd = document.getElementById("contraseña").value;

    if (input_usr == email && input_pwd == password)
        alert("Compra exitosa");
    else
        alert("Incorrecto");
}