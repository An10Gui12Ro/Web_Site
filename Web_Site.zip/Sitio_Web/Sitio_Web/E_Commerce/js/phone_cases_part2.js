const phone_cases_container = document.getElementById('phone_cases_container');


function create_cards_phone_cases(phone_cases){
    phone_cases.forEach(phone_case =>{
        const new_phone_case = document.createElement("div");
        new_phone_case.id = `phone_case_${phone_case.id}`;

        new_phone_case.innerHTML = `
            <img src= ${phone_case.img}>
            <h3>${phone_case.name}</h3>
            <p>$${phone_case.price}</p>
            <button>Agregar al carrito</button>
        `;
        
        phone_cases_container.appendChild(new_phone_case);

        new_phone_case.getElementsByTagName("button")[0].addEventListener("click", () => add_to_cart(phone_case));
    })
}

get_phone_cases().then(phone_cases =>{
    create_cards_phone_cases(phone_cases);
})


n_items().then(n_items =>{
    update_number_of_items(n_items);
})