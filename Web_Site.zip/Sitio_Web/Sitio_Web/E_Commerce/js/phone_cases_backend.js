async function get_phone_cases(){
    const res = await fetch('http://localhost:4000/phone_cases');
    const resJson = await res.json();
    return resJson;
}