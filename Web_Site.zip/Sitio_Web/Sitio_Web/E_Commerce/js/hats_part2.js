const hats_container = document.getElementById('hats_container');


function create_cards_hats(hats){
    hats.forEach(hat =>{
        const new_hat = document.createElement("div");
        new_hat.id = `hat_${hat.id}`;

        new_hat.innerHTML = `
            <img src= ${hat.img}>
            <h3>${hat.name}</h3>
            <p>$${hat.price}</p>
            <button>Agregar al carrito</button>
        `;
        
        hats_container.appendChild(new_hat);

        new_hat.getElementsByTagName("button")[0].addEventListener("click", () => add_to_cart(hat));
    })
}

get_hats().then(hats =>{
    create_cards_hats(hats);
})


n_items().then(n_items =>{
    update_number_of_items(n_items);
})