const hoodies_container = document.getElementById('hoodies_container');


function create_cards_hoodies(hoodies){
    hoodies.forEach(hoodie =>{
        const new_hoodie = document.createElement("div");
        new_hoodie.id = `hoodie_${hoodie.id}`;

        new_hoodie.innerHTML = `
            <img src= ${hoodie.img}>
            <h3>${hoodie.name}</h3>
            <p>$${hoodie.price}</p>
            <button>Agregar al carrito</button>
        `;
        
        hoodies_container.appendChild(new_hoodie);

        new_hoodie.getElementsByTagName("button")[0].addEventListener("click", () => add_to_cart(hoodie));
    })
}

get_hoodies().then(hoodies =>{
    create_cards_hoodies(hoodies);
})


n_items().then(n_items =>{
    update_number_of_items(n_items);
})