const express = require("express");
const morgan = require("morgan");
const cors = require("cors");
const database = require("./database");

//Configuracion inicial
const app = express();
app.set('port', 4000);
app.listen(app.get('port'));
console.log("Conected to port: " + app.get('port'));
//console.log("Este log es nuevo");

//Middleware
app.use(morgan('dev'));
app.use(cors({
    origin: ["http://127.0.0.1:5501", "http://127.0.0.1:5500"]
}))
app.use(express.json());


                //RUTAS//
//SHOW T_SHIRTS
app.get('/t_shirts', async (req, res) => {
    const connection = await database.getConnection();
    const result = await connection.query("SELECT * FROM t_shirts");
    //console.log(result);

    res.json(result);
})

//SHOW HOODIES
app.get('/hoodies', async (req, res) => {
    const connection = await database.getConnection();
    const result = await connection.query("SELECT * FROM hoodies");
    //console.log(result);

    res.json(result);
})

//SHOW HATS
app.get('/hats', async (req, res) => {
    const connection = await database.getConnection();
    const result = await connection.query("SELECT * FROM hats");
    //console.log(result);

    res.json(result);
})

//SHOW PHONE CASES
app.get('/phone_cases', async (req, res) => {
    const connection = await database.getConnection();
    const result = await connection.query("SELECT * FROM phone_cases");
    //console.log(result);

    res.json(result);
})

//ADD PRODUCT TO CART
app.post('/cart/add', async (req, res) => {
    const connection = await database.getConnection();
    const { id, name, amount, price } = req.body;

    try {
        // Verifica si el producto ya existe en el carrito
        const rows = await connection.query(
            'SELECT product_amount FROM cart WHERE user_id = ? AND product_id = ?',
            [1, id] //USER ID
        );

        if(rows && rows.length > 0) {
            /*console.log(rows);*/
            // Si el producto ya existe, actualiza la cantidad
            const newAmount = rows[0].product_amount + amount;
            await connection.query(
                'UPDATE cart SET product_amount = ? WHERE user_id = ? AND product_id = ?',
                [newAmount, 1, id] //USER ID
            );
            res.send('Product amount updated in cart');
        } else {
            // Si el producto no existe, insértalo
            await connection.query(
                'INSERT INTO cart (user_id, product_id, product_amount) VALUES (?, ?, ?)',
                [1, id, amount] //USER ID
            );
            res.send('Product added to cart');
        }
    } catch (err) {
        console.error(err);
        res.status(500).send('Error adding product to cart');
    }
});

//DELETE PRODUCT FROM CART
app.post('/cart/delete', async (req, res) => {
    const connection = await database.getConnection();
    const {id} = req.body;

    try {
        const result = await connection.query(
            'SELECT product_amount FROM cart WHERE user_id = ? AND product_id = ?',
            [1, id] //USER ID
        );
        /*console.log(result);*/
        const amount = result[0]['product_amount'];

        if(amount == 1){
            await connection.query(
                'DELETE FROM cart WHERE user_id = ? AND product_id = ?',
                [1, id]
            )
            res.send('Product deleted from cart');
        }
        else{
            await connection.query(
                'UPDATE cart SET product_amount = ? WHERE user_id = ? AND product_id = ?',
                [amount-1, 1, id]
            )
            res.send('Product amount updated in cart');
        }
    } catch (err) {
        console.error(err);
        res.status(500).send('Error deleting product to cart');
    }
});


//UPDATE CART
app.get('/cart/update', async (req, res) => {
    const connection = await database.getConnection();

    try {
        // Paso 1: Obtener los productos del carrito
        const cartItems = await connection.query(
            'SELECT product_id, product_amount FROM cart WHERE user_id = ?',
            [1] // USER ID
        );
        /*console.log(cartItems);*/

        const products = [];

        // Paso 2: Iterar sobre los resultados y hacer los INNER JOIN según sea necesario
        for(const item of cartItems) {
            let productDetails;
            /*console.log(productDetails);*/

            // Condición para determinar la tabla (puedes cambiar esta lógica según tu caso)
            if (item.product_id >= 1 && item.product_id <= 8) { //IDs desde 1 a 8 están en "t_shirt"
                productDetails = await connection.query(
                    'SELECT name, img, price FROM t_shirts WHERE id = ?',
                    [item.product_id]
                );
            } 
            else if(item.product_id >= 9 && item.product_id <= 16){ //IDs desde 9 a 16 están en "hoodies"
                productDetails = await connection.query(
                    'SELECT name, img, price FROM hoodies WHERE id = ?',
                    [item.product_id]
                );
            }
            else if(item.product_id >= 16 && item.product_id <= 24){ //IDs desde 17 a 24 están en "hats"
                productDetails = await connection.query(
                    'SELECT name, img, price FROM hats WHERE id = ?',
                    [item.product_id]
                );
            }
            else if(item.product_id >= 25 && item.product_id <= 32){ //IDs desde 25 a 32 están en "phone_cases"
                productDetails = await connection.query(
                    'SELECT name, img, price FROM phone_cases WHERE id = ?',
                    [item.product_id]
                );
            }

            /*console.log(productDetails);*/

            // Combinar los datos del carrito con los detalles del producto en un solo objeto
            products.push({
                id: item.product_id,
                amount: item.product_amount,
                ...productDetails[0] // Suponiendo que la consulta retorna un solo resultado se selecciona todas sus propiedades, es decir, 'name', 'img', 'price'
            });
        }

        /*console.log(products);*/

        res.json(products);
    } catch (error) {
        console.error('Error fetching cart details:', error);
        res.status(500).json({ error: 'Error fetching cart details' });
    }
});


//UPDATE NUMBER OF ITEMS
app.get('/cart/items', async (req, res) => {
    const connection = await database.getConnection();
    const result = await connection.query(
        'SELECT SUM(product_amount) FROM cart WHERE user_id = ?',
        [1] // USER ID
    );
    //console.log(result);

    res.json(result);
})


//IS CART EMPTY?
app.get('/cart/empty', async (req, res) => {
    const connection = await database.getConnection();

    try {
        // Paso 1: Obtener los productos del carrito
        const cartItems = await connection.query(
            'SELECT product_id, product_amount FROM cart WHERE user_id = ?',
            [1] // USER ID
        );

        let prices_sum = 0, amount_sum = 0;

        // Paso 2: Iterar sobre los resultados y hacer los INNER JOIN según sea necesario
        for (const item of cartItems) {
            let item_price = 0;

            // Condición para determinar la tabla (puedes cambiar esta lógica según tu caso)
            if (item.product_id >= 1 && item.product_id <= 8) { //IDs desde 1 a 8 están en "t_shirt"
                item_price = await connection.query(
                    'SELECT price FROM t_shirts WHERE id = ?',
                    [item.product_id]
                );
                /*console.log(item_price);*/
                item_price = item_price[0].price;
                /*console.log(item_price);*/
            } else if (item.product_id >= 9 && item.product_id <= 16) { //IDs desde 9 a 16 están en "hoodies"
                item_price = await connection.query(
                    'SELECT price FROM hoodies WHERE id = ?',
                    [item.product_id]
                );
                item_price = item_price[0].price;
            } else if (item.product_id >= 17 && item.product_id <= 24) { //IDs desde 17 a 24 están en "hats"
                item_price = await connection.query(
                    'SELECT price FROM hats WHERE id = ?',
                    [item.product_id]
                );
                item_price = item_price[0].price;
            } else if (item.product_id >= 25 && item.product_id <= 32) { //IDs desde 25 a 32 están en "phone_cases"
                item_price = await connection.query(
                    'SELECT price FROM phone_cases WHERE id = ?',
                    [item.product_id]
                );
                item_price = item_price[0].price;
            }

            item_price *= item.product_amount;
            amount_sum += item.product_amount;
            prices_sum += item_price;

            //console.log('Precio del item:', item_price);
            //console.log('Suma de precios:', prices_sum);
            //console.log('Suma de cantidades:', amount_sum);
        }

        // Combinar los datos del carrito con los detalles del producto en un solo objeto
        const products = [{
            amount_sum: amount_sum,
            prices_sum: prices_sum
        }];

        /*console.log(products);*/
        res.json(products);
    } catch (error) {
        console.error('Error fetching cart details:', error);
        res.status(500).json({ error: 'Error fetching cart details' });
    }
});

//DELETE ALL CART
app.delete('/cart/delete/all', async (req, res) => {
    const connection = await database.getConnection();

    try {
        // Elimina todos los registros de la tabla cart donde user_id sea igual a 1
        await connection.query(
            'DELETE FROM cart WHERE user_id = ?',
            [1] // Reemplaza 1 con el ID del usuario si es dinámico
        );
        
        res.status(200).send('All cart items deleted successfully');
    } catch (error) {
        console.error('Error deleting all items in cart:', error);
        res.status(500).send('Error deleting all items in cart');
    }
});